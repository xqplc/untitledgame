using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinScript : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        int f = PlayerPrefs.GetInt ("Coins", 0) + 1;

        if (other.name == "Player")
        {
            Destroy (gameObject);
            PlayerPrefs.SetInt ("Coins", f);
        }
    }
}
