using UnityEngine;

public class BlockSpawner : MonoBehaviour
{
    public Transform[] spawnPoints;

    public Transform[] coinSpawnPoints;

    public GameObject blockPrefab;

    public GameObject coinPrefab;

    public float timeBetweenWaves = 1f;

    private float timeToSpawn = 2f;

    void Update ()
    {
        if (Time.time >= timeToSpawn)
        {
            SpawnBlocks ();
            timeToSpawn = Time.time + timeBetweenWaves;
            foreach (Transform i in spawnPoints)
            {
                i.position = new Vector3 (i.position.x, i.position.y, i.position.z + 15);
            }
            foreach (Transform f in coinSpawnPoints)
            {
                f.position = new Vector3 (f.position.x, f.position.y, f.position.z + 15);
            }
        }
    }
    void SpawnBlocks ()
    {
        int randomIndex = Random.Range (0, spawnPoints.Length);
        int randomIndex2 = Random.Range (0, spawnPoints.Length);

        for (int i = 0; i < spawnPoints.Length; i++)
        {
            if (randomIndex != i && randomIndex2 != i)
            {
                GameObject obstacle = Instantiate(blockPrefab, spawnPoints[i].position, Quaternion.identity);
                Destroy (obstacle, 7f);
            } 
            else if (randomIndex == i || randomIndex2 == i)
            {
                if (Random.Range(0, 100) <= 25)
                {
                    GameObject f = Instantiate (coinPrefab, coinSpawnPoints[i].position, Quaternion.identity);
                    f.transform.Rotate (90, 0, 0);
                    Debug.Log ("spawned a coin");
                }
            }
        }
    }
}
