using UnityEngine;

public class ExitButton : MonoBehaviour
{
    public void Exit ()
    {
        Debug.Log("Quit");
        Application.Quit();
    }
}
