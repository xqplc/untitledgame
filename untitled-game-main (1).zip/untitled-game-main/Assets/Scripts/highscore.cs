using UnityEngine;
using UnityEngine.UI;

public class highscore : MonoBehaviour
{
    public Text highscoreText;
    private void Start()
    {
        if (PlayerPrefs.GetString("newHighScore") == "true")
        {
            highscoreText.text = "NEW HIGH SCORE: " + PlayerPrefs.GetInt ("HighScore").ToString () + "!";
            Debug.Log (PlayerPrefs.GetString ("newHighScore"));
        }
        else if (PlayerPrefs.GetString ("newHighScore") == "false")
        {
            Debug.Log ("no new highscore, highscore is" + PlayerPrefs.GetInt ("HighScore").ToString ());
            highscoreText.text = "";
        }
    }
}
