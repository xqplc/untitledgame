using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerCollision : MonoBehaviour
{

    public PlayerMovement movement;

    public Text scoreText;

    void OnCollisionEnter(Collision collisionInfo)
    {
        if (collisionInfo.collider.tag == "Obstacle")
        {
            int sText = int.Parse (scoreText.text);
            if (sText > PlayerPrefs.GetInt ("HighScore", 0))
            {
                PlayerPrefs.SetInt ("HighScore", sText);
                PlayerPrefs.SetString ("newHighScore", "true");
            }
            else if (sText < PlayerPrefs.GetInt ("HighScore"))
            {
                PlayerPrefs.SetString ("newHighScore", "false");
            }
            FindObjectOfType<GameManager> ().EndGame ();
            movement.enabled = false;
        }
    }

}
