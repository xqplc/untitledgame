using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public void EndGame()
    {

        Invoke ("loadDedScene", 1f);
    }
    void loadDedScene()
    {
        SceneManager.LoadScene (2);
    }
}
