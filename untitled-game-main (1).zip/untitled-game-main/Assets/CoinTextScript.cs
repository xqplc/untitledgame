using UnityEngine;
using UnityEngine.UI;

public class CoinTextScript : MonoBehaviour
{
    private void Update()
    {
        gameObject.GetComponent<Text> ().text = PlayerPrefs.GetInt ("Coins", 0).ToString();
    }
}
