using UnityEngine;
using System.Collections;

public class GroundScript : MonoBehaviour
{
    WaitForSeconds waitForSeconds = new WaitForSeconds (1f);

    IEnumerator Start()
    {
        while (true)
        {
            gameObject.transform.position = new Vector3 (0, 0, gameObject.transform.position.z + 10);
            yield return waitForSeconds;
        }
    }
    
        
        
   
       
    
}
